from django.shortcuts import render

def about_us(request):
	return render(request, "about_us.html")

def contacts(request):
	return render(request, "contacts.html")

def mainpage(request):
	return render(request, "mainpage.html")

def new_titles(request):
	return render(request, "new_titles.html")

def registration(request):
	return render(request, "registration.html")

# Create your views here.
