Сайт с каталогом аниме.

Пункты:

Авторизация
Система оценивания
Добавление отзывов
Данные о выбранном аниме
дизайн в фигме: https://www.figma.com/file/Y7KKqXYRnKqZroKF5SIwhK/animesite?node-id=0%3A1
